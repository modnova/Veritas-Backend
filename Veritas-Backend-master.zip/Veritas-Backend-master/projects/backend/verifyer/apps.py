from django.apps import AppConfig


class VerifyerConfig(AppConfig):
    name = 'verifyer'
