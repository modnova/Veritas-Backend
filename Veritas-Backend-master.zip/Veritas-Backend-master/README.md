# Veritas-Backend
Holds Django server and dependancies
